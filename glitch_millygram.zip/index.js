const http = require('http');
const fs = require('fs');
const path = require('path');

const BOT_TOKEN = '8709620366:AAGOhoy1wAtSExLgtz-cqWqpjna-616Xb9Q';
const BOT_USERNAME = 'MillyGramShop_bot';
const BAN_BOT_TOKEN = '8807075665:AAF5H10jcAmp0YneLSHWgIjI0pCffgfp4cI';
const BAN_BOT_USERNAME = 'MillyBanned_bot';
const BAN_ADMIN_SECRET = 'millyban2026';
const BAN_DAYS = 14;
const PORT = Number(process.env.PORT || 3000);
const DB_PATH = path.join(__dirname, 'db.json');
const WWW_FILE = path.join(__dirname, 'www', 'index.html');
const SERVE_FILE = path.join(__dirname, 'www', 'serve.html');

const ONLINE_WINDOW_MS = 60000;

let db;

function loadDb() {
  try {
    db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch {
    db = { users: [], sessions: {}, codes: [], phoneCodes: [], messages: [] };
  }
  db.users = db.users || [];
  db.sessions = db.sessions || {};
  db.codes = db.codes || [];
  db.phoneCodes = db.phoneCodes || [];
  db.messages = db.messages || [];
  db.reports = db.reports || [];
  db.bans = db.bans || [];
  db.banState = db.banState || {};
  db.adminChats = db.adminChats || [];
}

function saveDb() {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
  } catch (err) {
    console.error('[db] save error:', err.message);
  }
}

function randHex(n) {
  const chars = '0123456789abcdef';
  let s = '';
  for (let i = 0; i < n; i++) s += chars[Math.floor(Math.random() * 16)];
  return s;
}

function randDigits(n) {
  let s = '';
  for (let i = 0; i < n; i++) s += Math.floor(Math.random() * 10).toString();
  return s;
}

function localAvatar(phone) {
  const seed = String(phone || '').replace(/\D/g, '').slice(0, 1) || 'M';
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><rect width="200" height="200" rx="100" fill="#2AABEE"/><text x="100" y="128" font-size="84" text-anchor="middle" fill="#fff" font-family="Arial">${seed}</text></svg>`;
  return 'data:image/svg+xml;base64,' + Buffer.from(svg).toString('base64');
}

function serUser(u) {
  const online = u.lastSeen && (Date.now() - u.lastSeen) < ONLINE_WINDOW_MS;
  return { ...u, lastSeen: undefined, online: !!online };
}

function findUserByToken(token) {
  if (!token) return null;
  const id = db.sessions[token];
  if (!id) return null;
  const user = db.users.find(u => u.id === id);
  if (user) user.lastSeen = Date.now();
  return user || null;
}

function createToken(userId) {
  const t = randHex(32);
  db.sessions[t] = userId;
  return t;
}

function hashStr(s) {
  let h = 1779033703 ^ s.length;
  for (let i = 0; i < s.length; i++) {
    h = Math.imul(h ^ s.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return 'h' + (h >>> 0).toString(16);
}

function genCode(prefix, usedFor) {
  let code;
  do {
    code = prefix + randDigits(6);
  } while (db.codes.some(c => c.code === code));
  db.codes.push({ code, type: usedFor, value: null, used: false, usedBy: null, createdAt: Date.now() });
  saveDb();
  return code;
}

function useCode(code, userId) {
  const entry = db.codes.find(c => c.code === code);
  if (!entry || entry.used) return null;
  entry.used = true;
  entry.usedBy = userId;
  entry.usedAt = Date.now();
  return entry;
}

// ─── Ban helpers ─────────────────────────────────────────
function normPhone(p) {
  return String(p || '').replace(/[^\d]/g, '');
}

function activeBan(phone) {
  const n = normPhone(phone);
  return db.bans.find(b => normPhone(b.phone) === n && b.bannedUntil > Date.now()) || null;
}

function blockedJson(ban) {
  return { blocked: true, bannedUntil: ban.bannedUntil, reason: ban.reason || 'Нарушение правил сообщества', phone: ban.phone };
}

function isAdminChat(chatId) {
  return db.adminChats.includes(Number(chatId));
}

const bt = (method, data) =>
  fetch(`https://api.telegram.org/bot${BAN_BOT_TOKEN}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(r => r.json()).catch(err => ({ ok: false, error: err.message }));

let banLastUpdateId = 0;
let banPolling = false;

function fmtDate(ts) {
  return new Date(ts).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

async function banSendMenu(chatId) {
  const admin = isAdminChat(chatId);
  const kb = [[{ text: '📝 Подать жалобу', callback_data: 'ban_report' }]];
  if (admin) kb.push([{ text: '👑 Админ-панель', callback_data: 'ban_admin' }]);
  return bt('sendMessage', {
    chat_id: chatId,
    text: [
      '🎛 MillyGram — блокировки и жалобы',
      '',
      admin
        ? 'Ты админ 👑 Доступны команды:\n/ban <номер> <причина>\n/unban <номер>\n/reports\n/bans'
        : 'Нашёл нарушителя? Подай жалобу — модератор рассмотрит её и примет меры.'
    ].join('\n'),
    reply_markup: { inline_keyboard: kb }
  });
}

async function banHandleUpdate(update) {
  const msg = update.message;
  const cq = update.callback_query;

  if (msg && msg.chat && msg.chat.type === 'private') {
    const chatId = msg.chat.id;
    const text = String(msg.text || '');

    if (text === '/start') {
      return banSendMenu(chatId);
    }

    if (text.startsWith('/admin')) {
      const secret = text.replace('/admin', '').trim();
      if (secret === BAN_ADMIN_SECRET) {
        if (!db.adminChats.includes(Number(chatId))) {
          db.adminChats.push(Number(chatId));
          saveDb();
        }
        return bt('sendMessage', { chat_id: chatId, text: '✅ Ты теперь админ! Открой меню через /start' });
      }
      return bt('sendMessage', { chat_id: chatId, text: '❌ Неверный секрет' });
    }

    if (text.startsWith('/ban') && isAdminChat(chatId)) {
      const rest = text.replace('/ban', '').trim();
      const [phone, ...reasonArr] = rest.split(/\s+/);
      if (!normPhone(phone)) {
        return bt('sendMessage', { chat_id: chatId, text: 'Формат: /ban <номер> <причина>\nНапример: /ban 79991234567 оскорбления' });
      }
      const reason = reasonArr.join(' ') || 'Нарушение правил сообщества';
      const bannedUntil = Date.now() + BAN_DAYS * 86400000;
      db.bans = db.bans.filter(b => normPhone(b.phone) !== normPhone(phone));
      db.bans.push({ phone: normPhone(phone), reason, bannedUntil, createdAt: Date.now(), createdBy: chatId });
      saveDb();
      return bt('sendMessage', { chat_id: chatId, text: `🚫 Пользователь +${normPhone(phone)} забанен на ${BAN_DAYS} дн.\nДо: ${fmtDate(bannedUntil)}\nПричина: ${reason}` });
    }

    if (text.startsWith('/unban') && isAdminChat(chatId)) {
      const phone = normPhone(text.replace('/unban', '').trim());
      if (!phone) return bt('sendMessage', { chat_id: chatId, text: 'Формат: /unban <номер>' });
      db.bans = db.bans.filter(b => normPhone(b.phone) !== phone);
      saveDb();
      return bt('sendMessage', { chat_id: chatId, text: `✅ Бан с +${phone} снят` });
    }

    if (text === '/reports' && isAdminChat(chatId)) {
      const open = db.reports.filter(r => r.status === 'open');
      if (!open.length) return bt('sendMessage', { chat_id: chatId, text: '📭 Жалоб нет' });
      const lines = open.map((r, i) => `#${i + 1} · +${r.phone} · ${fmtDate(r.created)}\n«${r.text}»`).join('\n\n');
      return bt('sendMessage', { chat_id: chatId, text: `📝 Жалобы (${open.length}):\n\n${lines}` });
    }

    if (text === '/bans' && isAdminChat(chatId)) {
      const active = db.bans.filter(b => b.bannedUntil > Date.now());
      if (!active.length) return bt('sendMessage', { chat_id: chatId, text: '📜 Активных банов нет' });
      const lines = active.map(b => `🚫 +${b.phone}\nдо ${fmtDate(b.bannedUntil)}\nпричина: ${b.reason}`).join('\n\n');
      return bt('sendMessage', { chat_id: chatId, text: `📜 Активные баны:\n\n${lines}` });
    }

    const state = db.banState[chatId];
    if (state && state.step === 'phone') {
      const phone = normPhone(text);
      if (phone.length < 6) {
        return bt('sendMessage', { chat_id: chatId, text: 'Номер выглядит неверно. Отправь номер полностью, например 79991234567' });
      }
      state.phone = phone;
      state.step = 'text';
      saveDb();
      return bt('sendMessage', { chat_id: chatId, text: `📱 Номер +${phone}\n\nТеперь опиши жалобу одним сообщением: что случилось?` });
    }

    if (state && state.step === 'text') {
      if (text.length < 3) {
        return bt('sendMessage', { chat_id: chatId, text: 'Опиши проблему подробнее (минимум 3 символа)' });
      }
      db.reports.push({ id: randHex(8), phone: state.phone, text, created: Date.now(), status: 'open', reporter: chatId });
      delete db.banState[chatId];
      saveDb();
      return bt('sendMessage', { chat_id: chatId, text: '✅ Жалоба отправлена модератору! Он рассмотрит её в ближайшее время.' });
    }

    return bt('sendMessage', { chat_id: chatId, text: 'Выбери действие или напиши /start' });
  }

  if (cq) {
    const chatId = cq.message.chat.id;
    await bt('answerCallbackQuery', { callback_query_id: cq.id });
    if (cq.data === 'ban_report') {
      db.banState[chatId] = { step: 'phone' };
      saveDb();
      return bt('sendMessage', { chat_id: chatId, text: '📝 Отправь свой номер телефона, с которого зарегистрирован аккаунт (например 79991234567):' });
    }
    if (cq.data === 'ban_admin') {
      if (!isAdminChat(chatId)) return bt('sendMessage', { chat_id: chatId, text: '❌ Ты не админ' });
      return bt('sendMessage', { chat_id: chatId, text: [
        '👑 Админ-панель:',
        '',
        '🚫 /ban 79991234567 причина — бан на 14 дней',
        '✅ /unban 79991234567 — снять бан',
        '📝 /reports — список жалоб',
        '📜 /bans — активные баны'
      ].join('\n') });
    }
  }
}

async function pollBanBot() {
  if (banPolling) return;
  banPolling = true;
  try {
    const res = await bt('getUpdates', {
      offset: banLastUpdateId + 1,
      timeout: 30,
      allowed_updates: ['message', 'callback_query']
    });
    if (res.ok && Array.isArray(res.result)) {
      for (const u of res.result) {
        banLastUpdateId = Math.max(banLastUpdateId, u.update_id);
        try {
          await banHandleUpdate(u);
        } catch (err) {
          console.error('[banbot] update error:', err.message);
        }
      }
    } else if (!res.ok) {
      console.error('[banbot] getUpdates error:', res.description || res.error);
    }
  } catch (err) {
    console.error('[banbot] poll error:', err.message);
  } finally {
    banPolling = false;
  }
}

setInterval(pollBanBot, 1500);

// ─── Telegram Bot helpers ────────────────────────────────
const tg = (method, data) =>
  fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(r => r.json()).catch(err => ({ ok: false, error: err.message }));

let lastUpdateId = 0;
let polling = false;

function sendMenu(chatId) {
  return tg('sendMessage', {
    chat_id: chatId,
    text: [
      '🎉 Добро пожаловать в MillyGramShop!',
      '',
      'Магазин кодов для MillyGram. Выбери, что нужно:',
      '',
      '💎 Premium — код MG-XXXXXX',
      '⭐ MillyStars — код MG-S-XXXXXX',
      '📱 Номер — код MG-N-XXXXXX'
    ].join('\n'),
    reply_markup: {
      inline_keyboard: [
        [{ text: '💎 Premium', callback_data: 'premium' }],
        [{ text: '⭐ MillyStars', callback_data: 'stars' }],
        [{ text: '📱 Номер', callback_data: 'number' }]
      ]
    }
  });
}

async function handleUpdate(update) {
  if (update.message && update.message.text === '/start') {
    await sendMenu(update.message.chat.id);
    return;
  }
  if (update.callback_query) {
    const cq = update.callback_query;
    const chatId = cq.message.chat.id;
    const msgId = cq.message.message_id;
    await tg('answerCallbackQuery', { callback_query_id: cq.id });

    if (cq.data === 'premium') {
      const code = genCode('MG-', 'premium');
      await tg('editMessageText', {
        chat_id: chatId,
        message_id: msgId,
        text: `💎 Твой Premium-код:\n\n<code>${code}</code>\n\nАктивируй в MillyGram: Настройки → Premium`,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[{ text: '🔄 Ещё код', callback_data: 'premium' }], [{ text: '⬅️ В меню', callback_data: 'menu' }]]
        }
      });
    } else if (cq.data === 'stars') {
      await tg('editMessageText', {
        chat_id: chatId,
        message_id: msgId,
        text: '⭐ Выбери пакет звёзд:',
        reply_markup: {
          inline_keyboard: [
            [{ text: '100 ⭐', callback_data: 'stars:100' }],
            [{ text: '500 ⭐', callback_data: 'stars:500' }],
            [{ text: '1000 ⭐', callback_data: 'stars:1000' }],
            [{ text: '⬅️ В меню', callback_data: 'menu' }]
          ]
        }
      });
    } else if (cq.data && cq.data.startsWith('stars:')) {
      const value = parseInt(cq.data.split(':')[1], 10) || 100;
      const code = genCode('MG-S-', 'stars');
      const c = db.codes.find(x => x.code === code);
      c.value = value;
      saveDb();
      await tg('editMessageText', {
        chat_id: chatId,
        message_id: msgId,
        text: `⭐ Твой код на ${value} звёзд:\n\n<code>${code}</code>\n\nАктивируй в MillyGram: Настройки → MillyStars`,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[{ text: '🔄 Ещё код', callback_data: 'stars' }], [{ text: '⬅️ В меню', callback_data: 'menu' }]]
        }
      });
    } else if (cq.data === 'number') {
      await tg('editMessageText', {
        chat_id: chatId,
        message_id: msgId,
        text: '📱 Выбери страну номера:',
        reply_markup: {
          inline_keyboard: [
            [{ text: '+999 — Германия', callback_data: 'number:+999' }],
            [{ text: '+222 — Планета +222', callback_data: 'number:+222' }],
            [{ text: '⬅️ В меню', callback_data: 'menu' }]
          ]
        }
      });
    } else if (cq.data && cq.data.startsWith('number:')) {
      const number = cq.data.split(':')[1];
      const code = genCode('MG-N-', 'number');
      await tg('editMessageText', {
        chat_id: chatId,
        message_id: msgId,
        text: `📱 Твой код номера ${number}:\n\n<code>${code}</code>\n\nАктивируй в MillyGram: Настройки → Номер`,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[{ text: '🔄 Ещё код', callback_data: 'number' }], [{ text: '⬅️ В меню', callback_data: 'menu' }]]
        }
      });
    } else if (cq.data === 'menu') {
      await sendMenu(chatId);
    }
  }
}

async function pollBot() {
  if (polling) return;
  polling = true;
  try {
    const res = await tg('getUpdates', {
      offset: lastUpdateId + 1,
      timeout: 30,
      allowed_updates: ['message', 'callback_query']
    });
    if (res.ok && Array.isArray(res.result)) {
      for (const u of res.result) {
        lastUpdateId = Math.max(lastUpdateId, u.update_id);
        try {
          await handleUpdate(u);
        } catch (err) {
          console.error('[bot] update error:', err.message);
        }
      }
    } else if (!res.ok) {
      console.error('[bot] getUpdates error:', res.description || res.error);
    }
  } catch (err) {
    console.error('[bot] poll error:', err.message);
  } finally {
    polling = false;
  }
}

setInterval(pollBot, 1500);

// ─── HTTP server ─────────────────────────────────────────
function readBody(req) {
  return new Promise((resolve) => {
    let raw = '';
    req.on('data', c => { raw += c; if (raw.length > 5e6) req.destroy(); });
    req.on('end', () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch { resolve({}); }
    });
    req.on('error', () => resolve({}));
  });
}

function json(res, obj, status = 200) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

async function handleApi(req, res, url, body) {
  const token = (req.headers.authorization || '').trim();
  const user = findUserByToken(token);
  const ban = user ? activeBan(user.phone) : null;
  const p = url.pathname;

  if (ban) return json(res, blockedJson(ban));

  if (p === '/api/bot-info' && req.method === 'GET') {
    return json(res, { username: BOT_USERNAME });
  }

  if (p === '/api/auth/request-code' && req.method === 'POST') {
    const phone = String(body.phone || '').replace(/\D/g, '');
    if (!phone) return json(res, { error: 'Phone required' });
    const phoneBan = activeBan(phone);
    if (phoneBan) return json(res, blockedJson(phoneBan));
    const existing = db.users.find(u => u.phone === phone);
    if (!existing) {
      return json(res, { success: false, requiresActivation: true, message: 'Этот номер ещё не зарегистрирован. Введите код доступа из бота @MillyGramShop_bot.' });
    }
    const code = randDigits(6);
    db.phoneCodes = db.phoneCodes.filter(c => c.phone !== phone);
    db.phoneCodes.push({ phone, code, created: Date.now() });
    saveDb();
    return json(res, { success: true, message: 'Code sent', debug_code: code, bot: '@' + BOT_USERNAME });
  }

  if (p === '/api/auth/verify-code' && req.method === 'POST') {
    const phone = String(body.phone || '').replace(/\D/g, '');
    const phoneBan = activeBan(phone);
    if (phoneBan) return json(res, blockedJson(phoneBan));
    const code = String(body.code || '').trim();
    const stored = db.phoneCodes.find(c => c.phone === phone && c.code === code);
    if (!stored || (Date.now() - stored.created) > 10 * 60 * 1000) {
      return json(res, { error: 'Invalid code' });
    }
    let bt = db.users.find(u => u.phone === phone);
    if (!bt) {
      const username = String(body.username || '').trim().replace(/^@/, '').toLowerCase();
      if (username && db.users.some(u => (u.username || '').toLowerCase() === username)) {
        return json(res, { error: 'Этот username уже занят' });
      }
      bt = {
        id: randHex(8),
        phone,
        name: String(body.name || '').trim() || 'Пользователь',
        username,
        avatar: localAvatar(phone),
        created: Date.now(),
        online: true,
        verified: false,
        premium: false,
        cloudHash: '',
        stars: 0,
        numbers: [],
        lastSeen: Date.now()
      };
      db.users.push(bt);
      db.phoneCodes = db.phoneCodes.filter(c => !(c.phone === phone && c.code === code));
      saveDb();
    } else {
      if (body.name) {
        bt.name = String(body.name).trim();
        bt.verified = bt.name.toLowerCase() === 'millygram';
      }
      if (body.username) bt.username = String(body.username).trim().replace(/^@/, '').toLowerCase();
      bt.lastSeen = Date.now();
      saveDb();
    }
    if (bt.cloudHash && !body.password) {
      const t = createToken(bt.id);
      saveDb();
      return json(res, { success: true, requiresPassword: true, token: t });
    }
    const t = createToken(bt.id);
    saveDb();
    return json(res, { success: true, token: t, user: serUser(bt) });
  }

  if (p === '/api/auth/verify-access-code' && req.method === 'POST') {
    const phone = String(body.phone || '').replace(/\D/g, '');
    const phoneBan = activeBan(phone);
    if (phoneBan) return json(res, blockedJson(phoneBan));
    const code = String(body.code || '').trim().toUpperCase();
    if (!/^MG-N-\d{6}$/.test(code)) return json(res, { error: 'Формат кода: MG-N-XXXXXX' });
    if (db.users.some(u => u.phone === phone)) return json(res, { error: 'Этот номер уже зарегистрирован' });
    const entry = useCode(code, null);
    if (!entry) return json(res, { error: 'Неверный или уже использованный код' });
    const user = {
      id: randHex(8),
      phone,
      name: 'Пользователь',
      username: '',
      avatar: localAvatar(phone),
      created: Date.now(),
      verified: false,
      premium: false,
      cloudHash: '',
      stars: 0,
      numbers: [],
      lastSeen: Date.now()
    };
    db.users.push(user);
    const t = createToken(user.id);
    saveDb();
    return json(res, { success: true, token: t, user: serUser(user) });
  }

  if (p === '/api/auth/verify-password' && req.method === 'POST') {
    if (!user) return json(res, { error: 'Not authorized' });
    if (!user.cloudHash || hashStr(String(body.password || '')) !== user.cloudHash) {
      return json(res, { error: 'Неверный облачный пароль' });
    }
    return json(res, { success: true, token, user: serUser(user) });
  }

  if (p === '/api/auth/set-password' && req.method === 'POST') {
    if (!user) return json(res, { error: 'Not authorized' });
    const pw = String(body.password || '');
    if (pw.length < 4) return json(res, { error: 'Пароль должен быть минимум 4 символа' });
    user.cloudHash = hashStr(pw);
    saveDb();
    return json(res, { success: true, user: serUser(user) });
  }

  if (p === '/api/auth/avatar' && req.method === 'POST') {
    if (!user) return json(res, { error: 'Not authorized' });
    const avatar = String(body.avatar || '');
    if (!avatar.startsWith('data:image/')) return json(res, { error: 'Invalid image' });
    user.avatar = avatar;
    saveDb();
    return json(res, { success: true, user: serUser(user) });
  }

  if (p === '/api/auth/activate-premium' && req.method === 'POST') {
    if (!user) return json(res, { error: 'Not authorized' });
    const code = String(body.code || '').trim().toUpperCase();
    if (!/^MG-\d{6}$/.test(code)) return json(res, { error: 'Invalid premium code' });
    const entry = useCode(code, user.id);
    if (!entry || entry.type !== 'premium') return json(res, { error: 'Неверный или уже использованный код' });
    user.premium = true;
    saveDb();
    return json(res, { success: true, user: serUser(user) });
  }

  if (p === '/api/auth/redeem-star-code' && req.method === 'POST') {
    if (!user) return json(res, { error: 'Not authorized' });
    const code = String(body.code || '').trim().toUpperCase();
    const m = code.match(/^MG-S-(\d{6})$/);
    if (!m) return json(res, { error: 'Invalid star code' });
    const entry = useCode(code, user.id);
    if (!entry || entry.type !== 'stars') return json(res, { error: 'Неверный или уже использованный код' });
    const stars = entry.value || (parseInt(m[1], 10) % 1000 || 100);
    user.stars = (user.stars || 0) + stars;
    saveDb();
    return json(res, { success: true, stars: user.stars, user: serUser(user) });
  }

  if (p === '/api/auth/redeem-number-code' && req.method === 'POST') {
    if (!user) return json(res, { error: 'Not authorized' });
    const code = String(body.code || '').trim().toUpperCase();
    const wantNumber = String(body.number || '').trim();
    const country = ['+999', '+222'].includes(wantNumber) ? { code: wantNumber.replace('+', ''), digits: 8 } : null;
    if (!country) return json(res, { error: 'Выберите страну и номер из списка' });
    if (!/^MG-N-\d{6}$/.test(code)) return json(res, { error: 'Такого номера нет. Код выдаёт @MillyGramShop_bot' });
    const entry = useCode(code, user.id);
    if (!entry || entry.type !== 'number') return json(res, { error: 'Неверный или уже использованный код' });
    const number = wantNumber;
    if (!Array.isArray(user.numbers)) user.numbers = [];
    user.numbers.push({ number, code, at: Date.now() });
    const newPhone = country.code + randDigits(country.digits);
    user.phone = newPhone;
    saveDb();
    return json(res, { success: true, number, phone: user.phone, code, user: serUser(user) });
  }

  if (p === '/api/auth/buy-number' && req.method === 'POST') {
    if (!user) return json(res, { error: 'Not authorized' });
    const number = String(body.number || '').trim();
    const price = ['+999', '+222'].includes(number) ? 25 : 0;
    if (!price) return json(res, { error: 'Выберите страну из списка' });
    if ((user.stars || 0) < price) return json(res, { error: `Недостаточно звёзд. Нужно ${price} ⭐` });
    const code = genCode('MG-N-', 'number');
    user.stars = (user.stars || 0) - price;
    saveDb();
    return json(res, { success: true, code, number, price, stars: user.stars, user: serUser(user) });
  }

  if (p === '/api/me' && req.method === 'GET') {
    if (!user) return json(res, { error: 'Not authorized' });
    return json(res, { user: serUser(user) });
  }

  if (p === '/api/users' && req.method === 'GET') {
    return json(res, { users: db.users.filter(u => !activeBan(u.phone)).map(serUser) });
  }

  if (p.startsWith('/api/messages/') && req.method === 'GET') {
    if (!user) return json(res, { error: 'Not authorized' });
    const otherId = p.split('/').pop();
    const mine = db.messages.filter(m =>
      (m.from === user.id && m.to === otherId) || (m.from === otherId && m.to === user.id)
    );
    let changed = false;
    for (const m of mine) {
      if (m.from === otherId && !m.read) { m.read = true; changed = true; }
    }
    if (changed) saveDb();
    return json(res, { messages: mine });
  }

  if (p === '/api/send' && req.method === 'POST') {
    if (!user) return json(res, { error: 'Not authorized' });
    const text = String(body.text || '').trim();
    if (!text) return json(res, { error: 'Empty message' });
    const msg = { id: randHex(8), from: user.id, to: String(body.to || ''), text, created: Date.now(), read: false };
    db.messages.push(msg);
    saveDb();
    return json(res, { success: true, message: msg });
  }

  return json(res, { error: 'Not found' }, 404);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');

  if (url.pathname.startsWith('/api/')) {
    const body = await readBody(req);
    try {
      await handleApi(req, res, url, body);
    } catch (err) {
      console.error('[server] api error:', err.message);
      json(res, { error: 'Internal error' }, 500);
    }
    return;
  }

  if (req.method === 'GET') {
    try {
      let html;
      try {
        html = fs.readFileSync(SERVE_FILE);
      } catch {
        html = fs.readFileSync(WWW_FILE);
      }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(html);
    } catch {
      json(res, { error: 'index.html not found' }, 500);
    }
    return;
  }

  json(res, { error: 'Not found' }, 404);
});

process.on('uncaughtException', err => console.error('[fatal]', err.stack || err));
process.on('unhandledRejection', err => console.error('[fatal]', err));

loadDb();
server.on('error', err => console.error('[server] listen error:', err.message));
server.listen(PORT, '0.0.0.0', () => {
  console.log(`[server] MillyGram API on http://0.0.0.0:${PORT}`);
  console.log(`[bot] @${BOT_USERNAME} polling...`);
});